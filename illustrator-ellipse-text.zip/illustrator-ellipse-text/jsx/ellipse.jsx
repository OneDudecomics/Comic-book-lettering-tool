/**
 * Ellipse Text — ExtendScript (JSX)
 * ES3-compatible (no JSON, no forEach, no arrow functions).
 *
 * Receives a pipe-delimited string from the CEP panel:
 *   text|ellipseW|ellipseH|fontName|fontSize|lineGap|textColor|fillColor|strokeColor|strokeW|showEllipse
 *
 * Places text as a single area-text frame shaped to an ellipse,
 * centre-aligned, with Illustrator handling all text wrapping natively.
 */

// ── Colour helper ─────────────────────────────────────────────────────────────
function hexToRgbColor(hex) {
    var clean = hex.replace("#", "");
    var r = parseInt(clean.substring(0, 2), 16);
    var g = parseInt(clean.substring(2, 4), 16);
    var b = parseInt(clean.substring(4, 6), 16);
    var c = new RGBColor();
    c.red   = r;
    c.green = g;
    c.blue  = b;
    return c;
}

// ── Main entry point ──────────────────────────────────────────────────────────
function generateEllipseText(paramStr) {
    try {
        var parts        = paramStr.split("|");
        var text         = parts[0];
        var ellipseW     = parseFloat(parts[1]);
        var ellipseH     = parseFloat(parts[2]);
        var fontName     = parts[3];
        var ptSize       = parseFloat(parts[4]);
        var lineGap      = parseFloat(parts[5]);
        var textColorH   = parts[6];
        var fillColorH   = parts[7];
        var strokeColorH = parts[8];
        var strokeW      = parseFloat(parts[9]);
        var showEllipse  = (parts[10] === "true");

        var doc = app.activeDocument;
        if (!doc) return "ERROR:No active document.";
        if (text.replace(/\s+/g, "").length === 0) return "ERROR:Please enter some text.";

        var semiA = ellipseW / 2;
        var semiB = ellipseH / 2;

        // Centre on the active artboard
        var ab  = doc.artboards[doc.artboards.getActiveArtboardIndex()];
        var abR = ab.artboardRect;  // [left, top, right, bottom]
        var cx  = (abR[0] + abR[2]) / 2;
        var cy  = (abR[1] + abR[3]) / 2;

        // Create a group to hold all elements
        var grp  = doc.groupItems.add();
        grp.name = "Ellipse Text";

        // 1. Visible balloon ellipse (optional) ───────────────────────────────
        if (showEllipse) {
            var ellPath = doc.pathItems.ellipse(cy + semiB, cx - semiA, ellipseW, ellipseH);
            ellPath.name      = "Balloon";
            ellPath.filled    = true;
            ellPath.fillColor = hexToRgbColor(fillColorH);
            ellPath.stroked   = (strokeW > 0);
            if (strokeW > 0) {
                ellPath.strokeColor = hexToRgbColor(strokeColorH);
                ellPath.strokeWidth = strokeW;
            }
            ellPath.move(grp, ElementPlacement.PLACEATEND);
        }

        // 2. Inner ellipse as the text container (invisible) ──────────────────
        // Inset so text doesn't run right to the balloon edge.
        var inset  = Math.max(ptSize * 0.6, 6);
        var innerW = Math.max(10, ellipseW - inset * 2);
        var innerH = Math.max(10, ellipseH - inset * 2);

        var containerPath = doc.pathItems.ellipse(
            cy + innerH / 2,
            cx - innerW / 2,
            innerW,
            innerH
        );
        containerPath.filled  = false;
        containerPath.stroked = false;
        containerPath.name    = "TextContainer";

        // 3. Single area-text frame — Illustrator wraps text to the ellipse ───
        var tf = doc.textFrames.areaText(containerPath);
        tf.contents = text;

        var ca    = tf.textRange.characterAttributes;
        ca.size   = ptSize;
        ca.fillColor = hexToRgbColor(textColorH);
        ca.leading   = ptSize + lineGap;

        try {
            ca.textFont = app.textFonts.getByName(fontName);
        } catch (e) {
            // Font not found — Illustrator uses its default fallback
        }

        // Centre-align text horizontally
        tf.textRange.paragraphAttributes.justification = Justification.CENTER;

        // Centre-align text vertically within the shape
        try {
            tf.textPath.textVerticalAlignment = TextVerticalAlignment.CENTER;
        } catch (e) {
            try { tf.verticalAlignment = TextVerticalAlignment.CENTER; } catch (e2) {}
        }

        tf.move(grp, ElementPlacement.PLACEATEND);

        doc.selection = [grp];
        return "OK";

    } catch (err) {
        return "ERROR:" + err.message;
    }
}
