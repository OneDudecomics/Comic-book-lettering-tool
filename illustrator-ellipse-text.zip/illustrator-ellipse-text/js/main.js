/* global CSInterface */

(function () {
  var cs = new CSInterface();

  function setStatus(msg, type) {
    var el = document.getElementById("status");
    el.textContent = msg;
    el.className = type || "";
  }

  document.getElementById("generateBtn").addEventListener("click", function () {
    var text = document.getElementById("inputText").value.trim();
    if (!text) { setStatus("Please enter some text.", "err"); return; }

    // Replace pipe characters in text to avoid breaking the delimiter
    var safeText = text.replace(/\|/g, " ");

    // Build pipe-delimited param string passed to ExtendScript:
    // text|ellipseW|ellipseH|fontName|fontSize|lineGap|textColor|fillColor|strokeColor|strokeW|showEllipse
    var params = [
      safeText,
      document.getElementById("ellipseW").value,
      document.getElementById("ellipseH").value,
      document.getElementById("fontName").value.trim() || "Arial-BoldMT",
      document.getElementById("fontSize").value,
      document.getElementById("lineGap").value,
      document.getElementById("textColor").value,
      document.getElementById("fillColor").value,
      document.getElementById("strokeColor").value,
      document.getElementById("strokeW").value,
      document.getElementById("showEllipse").checked ? "true" : "false"
    ].join("|");

    setStatus("Placing text\u2026");

    // Escape single quotes and backslashes for evalScript
    var escaped = params.replace(/\\/g, "\\\\").replace(/'/g, "\\'");
    cs.evalScript("generateEllipseText('" + escaped + "')", function (result) {
      if (!result || result === "undefined") {
        setStatus("No response from Illustrator.", "err");
        return;
      }
      if (result === "OK") {
        setStatus("Done \u2014 text placed.", "ok");
      } else {
        setStatus(result.replace("ERROR:", ""), "err");
      }
    });
  });
})();
